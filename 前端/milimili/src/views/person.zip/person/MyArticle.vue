<template>
    <div class="myart1">
          <el-empty
          :image-size="250"
          description="你还没有发表任何视频哦"
        ></el-empty>
    </div>
  </template>
  
  <style>
    .myart1{
      line-height: 30px;
    }
  </style>
  
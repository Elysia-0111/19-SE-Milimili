<template>
    <div class="myart1">
      <el-empty
          :image-size="250"
          description="暂未收藏任何视频额"
        ></el-empty>
    </div>
  </template>

  <style>
  .el-card {
      border-radius: 0;
    }
  
    .el-card:not(:first-child) {
      margin-top: 5px;
  
    }
    .myart1{
      line-height: 30px;
    }
  </style>
  